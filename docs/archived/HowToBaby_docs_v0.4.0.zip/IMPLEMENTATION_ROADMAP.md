\
# IMPLEMENTATION_ROADMAP — HowToBaby

> Canonical execution sequence. This document owns phase ordering and release gates; permanent product/domain rules belong to the specialist contracts.

## Phase 0 — Documentation and repository baseline

**Goal:** freeze contracts before production implementation.

Deliverables:

- adopt v0.4.0 documentation set;
- repository structure;
- coding/PR conventions;
- CI skeleton;
- decisions recorded for static hosting and deployment target.

Gate:

- docs have no unresolved architecture contradictions;
- `PROJECT_PROFILE` references current specialist docs.

## Phase 1 — App shell + theme engine

**Goal:** establish a reusable UI foundation before domain screens multiply.

Deliverables:

- Next.js + TypeScript static export;
- `ThemeProvider`/Theme Registry;
- Baby Modern Glass Light/Dark token packs;
- typography/spacing/radius/motion foundations;
- AppShell/Header/Nav;
- responsive baseline;
- print profile scaffold;
- theme token completeness validation.

Gate:

- components contain no Baby Modern Glass-specific raw palette dependencies outside theme definitions;
- Light/Dark geometry parity verified;
- static build deploys.

## Phase 2 — Content/source schema platform

**Goal:** make evidence structured before migrating large amounts of prose.

Deliverables:

- SourceRecord schema;
- Claim/GuidanceBlock/applicability/precision/review schemas;
- content version manifest;
- EN/VI key framework;
- source ID/provenance validation;
- coverage matrix framework;
- trust-page scaffolds.

Gate:

- invalid source IDs/claim classes/precision states fail CI;
- one sample claim renders EN/VI from canonical data.

## Phase 3 — Age/context + browse/public routing

**Goal:** establish deterministic context without tying all access to a profile.

Deliverables:

- date utilities;
- chronological age;
- corrected-development proxy;
- actual/browsed/preview state isolation;
- Browse by Age;
- optional local profile;
- static public route generation;
- Why-this-stage component.

Gate:

- boundary/timezone tests pass;
- browse works with zero profile data;
- exact child data never enters URL/metadata.

## Phase 4 — Play & Development domain

**Goal:** migrate the development prototype into the canonical content graph.

Deliverables:

- stage map;
- milestone context;
- activities/variations;
- corrected-age handling;
- stage navigator;
- source audit;
- print stage/all-stage support.

Gate:

- milestones are not pass/fail;
- CDC checklist resolution behavior tested;
- EN/VI/content coverage passes.

## Phase 5 — Sleep + Safe Sleep domain

**Goal:** migrate the sleep prototype while separating evidence classes.

Deliverables:

- official duration source matrix;
- safe-sleep guidance;
- responsive newborn mode;
- nap/wake-window heuristic model;
- editable example plan;
- settling vs behavioral-method architecture;
- sleep print views.

Gate:

- 0–2m defaults responsive;
- heuristic labels visible;
- browsed stage cannot suppress actual infant safety;
- sleep events do not dictate feeding frequency.

## Phase 6 — Feeding + Feeding Safety domain

**Goal:** build a complete age/readiness-aware feeding contract.

Deliverables:

- feeding stage resolver;
- what/how/texture/responsive feeding;
- solids readiness education;
- iron/nutrient content;
- allergen architecture;
- choking preparation metadata;
- formula/breast-milk handling;
- source audit.

Gate:

- 4-month birthday alone does not unlock solids;
- allergen branches remain source-specific;
- choking-relevant examples have preparation metadata;
- safety-critical claims meet review policy.

## Phase 7 — Personalized Now composer

**Goal:** combine independent domain outputs into the core HowToBaby experience.

Deliverables:

- What Matters Now;
- Feed/Play/Sleep/Safety focus cards;
- Know/Do/Why/Watch/Source disclosure;
- example routine/timeline;
- adjustments drawer;
- content freshness summary.

Gate:

- no false precision;
- safety can override example plan;
- public and personalized views resolve equivalent claim IDs where contexts match.

## Phase 8 — Tools Platform + Audio Tools MVP

**Goal:** prove HowToBaby is a platform, not only a knowledge site.

Deliverables:

- Tool Registry;
- Tools hub;
- ToolShell/ToolCard;
- shared AudioSession;
- Lullaby Player;
- Ambient/Frequency Player with optional 432 Hz preset;
- sleep timer/fade-out;
- persistent mini-player if UX remains clean;
- utility-vs-guidance labels.

Gate:

- no therapeutic 432 Hz claim;
- audio requires user gesture;
- player accessible and stable across navigation;
- tool metadata/schema validation passes.

## Phase 9 — Evidence Watch v1

**Goal:** automate source-change detection without autonomous medical rewriting.

Deliverables:

- source monitor registry;
- adapter interface;
- CDC structured adapter where applicable;
- FDA RSS/structured adapter where applicable;
- AAP policy-index monitor;
- WHO feed/page monitor;
- hash/section diff;
- source→claim reverse dependency index;
- Markdown/JSON change reports;
- scheduled GitHub Actions workflow.

Gate:

- unchanged sources do not create noise;
- a test source change flags only dependent claims/routes/tools;
- semantic changes cannot auto-deploy canonical medical prose.

## Phase 10 — Trust, public discoverability, print, accessibility hardening

**Goal:** make the site credible and usable outside the personalized app flow.

Deliverables:

- Methodology;
- Sources;
- Editorial Policy;
- Medical Disclaimer;
- Changelog/Corrections;
- public age/topic metadata;
- sitemap/robots strategy;
- Letter/A4 QA;
- accessibility pass;
- performance pass.

Gate:

- trust pages are discoverable;
- no child data is indexable;
- public content is generated from canonical graph;
- no unsupported SEO-strengthened claims.

## Phase 11 — Release hardening / public v1

Deliverables:

- full source audit;
- content-version freeze;
- EN/VI parity complete for shipped scope;
- unit/E2E/visual/print build green;
- rollback procedure tested;
- production deployment automation;
- privacy/security review;
- content correction workflow documented.

Release gate:

- no known safety-critical `review-required` claim ships as approved;
- no known superseded source is marked current;
- all v1 routes/tools/themes build deterministically.

## Phase 12 — Post-v1 optional capabilities

Candidate work, not required for launch:

- PWA/offline audio/content packs;
- more Tools;
- optional logs/reminders;
- multi-child/sync;
- real-time recall alerts;
- Evidence Watch AI-assisted semantic diff/draft PRs;
- source-grounded Ask HowToBaby;
- additional evidence domains/locales.

## Cross-phase rules

- Do not build the final Now composer before domain resolvers are stable.
- Do not let Tools hard-code duplicate medical prose.
- Do not implement AI-assisted evidence rewriting before deterministic monitoring/provenance exists.
- Do not add a user backend merely to run Evidence Watch.
- Every phase must leave production code cleaner than the prototype architecture it replaces.
