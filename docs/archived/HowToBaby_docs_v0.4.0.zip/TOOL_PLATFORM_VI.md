\
# TOOL_PLATFORM — Bản tiếng Việt

> Tools là first-class feature nhưng tách khỏi evidence-backed guidance.

## Tool classes

```text
utility
guidance-linked
safety-sensitive
```

`utility`: hữu ích mà không cần health claim, ví dụ lullaby player/timer.

`guidance-linked`: output dựa canonical claims.

`safety-sensitive`: output sai có thể ảnh hưởng safety, cần gate nghiêm hơn.

## Tool Registry

Mỗi tool có `id`, `slug`, `titleKey`, `descriptionKey`, `category`, `toolClass`, `ageApplicability`, `requiresProfile`, `guidanceClaimIds`, `safetyClaimIds`, `module`.

Hub/route/nav sinh từ registry, không hard-code từng tool.

## Audio tools ban đầu

- Lullaby Player.
- Ambient/Frequency Player, có thể có 432 Hz preset.

Shared audio engine dùng HTMLMediaElement/Web Audio API. AudioContext chỉ start/resume sau user gesture.

## 432 Hz

Có thể là audio preference/preset. Không được quảng bá là medically superior, sleep therapy, developmental benefit... nếu chưa có approved evidence.

## Audio safety

- không autoplay;
- có stop rõ;
- volume UI chỉ là device level, không đồng nghĩa dB ở tai bé;
- safety guidance nếu có phải reference canonical claim IDs;
- không hard-code safety medical prose trong tool.

## Guidance-linked tool

Tool reference claim IDs rồi resolver lấy content; không copy/paste claim vào tool code.

## Calculator/planner

Arithmetic tách khỏi medical interpretation. Exact schedule output phải label Example/Heuristic nếu source không quy định exact target.

## Future tracking

Không compliance scoring, không tự diagnosis, không guilt-based streak. Local-first cho đến khi sync architecture được approve.
