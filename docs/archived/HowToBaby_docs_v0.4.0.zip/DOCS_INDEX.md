\
# HowToBaby Documentation Map

> Documentation ownership map for HowToBaby. This file exists to keep contracts in one place and prevent the same rule from drifting across multiple documents.

| Document | Role | Owns | Must not duplicate in detail |
|---|---|---|---|
| `PROJECT_PROFILE_v0.4.0.md` | Canonical product contract | mission, scope, invariants, product pillars, trust boundaries, high-level architecture decisions | component specs, phase task lists, crawler implementation details |
| `GUIDANCE_CONTENT_CONTRACT.md` | Canonical guidance/domain contract | age logic, stage maps, feeding/play/sleep/safety rules, evidence-to-action content behavior | visual styling, deployment architecture |
| `SYSTEM_ARCHITECTURE.md` | Canonical software architecture | package boundaries, runtime/build-time separation, content compilation, deployment topology | detailed medical content wording |
| `GUI_DESIGN.md` | Canonical UI/design contract | information architecture, theme engine, tokens, components, responsive/print/accessibility behavior | medical policy, crawler logic |
| `TOOL_PLATFORM.md` | Canonical utility/tool contract | tool registry, safety classes, audio-tool architecture, tool UX, future tool extensibility | evidence crawling and domain medical rules |
| `EVIDENCE_UPDATE_ENGINE.md` | Canonical source-monitoring/update contract | source adapters, change detection, dependency invalidation, review workflow, optional AI-assist policy | end-user visual design |
| `IMPLEMENTATION_ROADMAP.md` | Canonical execution sequence | phases, dependencies, gates, release readiness | permanent product rules already owned elsewhere |

## Conflict resolution

When documents conflict, use this precedence:

1. `PROJECT_PROFILE_v0.4.0.md` for product-level non-negotiable decisions.
2. The domain-specific owner document in the table above.
3. `IMPLEMENTATION_ROADMAP.md` for sequence only, never to override a product/domain contract.

A change that modifies a product invariant must update the Project Profile and Decision Log first. A change that only modifies implementation detail should update the owning detail document without expanding the Project Profile.

## Canonical language

English documents are canonical for implementation. Vietnamese companion documents are for review/readability and must preserve the same decisions. Identifiers, schemas, filenames, route names, and code contracts remain in English in both versions.
