\
# SYSTEM_ARCHITECTURE — HowToBaby

> Canonical software architecture for the public web app, content build system, tools platform, and evidence operations.

## 1. Architectural goals

- Keep the public product static-first and privacy-preserving.
- Make guidance, tools, themes, translations, and source provenance schema-driven.
- Allow source monitoring to run independently of user traffic.
- Make every published content version reproducible and rollbackable.
- Avoid a future rewrite when Tools, Evidence Update Engine, or optional sync are added.

## 2. Three-plane architecture

```text
┌───────────────────────────────────────────────────────────────┐
│  PUBLIC RUNTIME                                               │
│  Next.js static export + client personalization + tools       │
└───────────────────────────────────────────────────────────────┘
                         ▲ compiled artifacts
                         │
┌───────────────────────────────────────────────────────────────┐
│  BUILD / CONTENT PLANE                                        │
│  schemas → source registry → content graph → i18n → pages     │
└───────────────────────────────────────────────────────────────┘
                         ▲ reviewed changes
                         │
┌───────────────────────────────────────────────────────────────┐
│  EVIDENCE OPERATIONS                                          │
│  scheduled adapters → fingerprints/diffs → impact → PR/review │
└───────────────────────────────────────────────────────────────┘
```

The Evidence Operations plane may run in GitHub Actions or a small scheduled worker. It is not a request-time backend for child profiles.

## 3. Recommended repository layout

```text
apps/
  web/                     # Next.js public app
packages/
  domain/                  # age/context/resolvers
  content-schema/          # source/claim/guidance schemas
  content/                 # canonical reviewed content
  i18n/                    # locale infrastructure/parity
  ui/                      # theme engine + components
  tools-core/              # Tool Registry/runtime contracts
  tools-audio/             # optional audio tools package
  validation/              # build-time validators
services/
  evidence-watch/          # scheduled source monitoring
scripts/
  build-content/
  generate-public-pages/
  validate-content/
  release-content/
docs/
  ...
```

A single-repo `src/` layout is acceptable early on, but package boundaries above should still be respected logically.

## 4. Public web runtime

### 4.1 Static-first

- Generate public age/topic/trust pages at build time.
- Client JavaScript is used for local profile personalization, theme/language preferences, interactive Tools, and preview state.
- No child profile is sent to a server in v1.

### 4.2 Route families

Conceptual routes:

```text
/
/now
/feeding/...
/play/...
/sleep/...
/safety/...
/tools
/tools/lullaby
/tools/audio
/sources
/methodology
/editorial-policy
/medical-disclaimer
/changelog
```

Exact slugs can change without changing architecture.

### 4.3 Public and personalized content

Both resolve from the same compiled content graph. Do not fork medical prose into SEO-only copies.

## 5. Content build pipeline

```text
source registry
  + canonical English claims
  + applicability rules
  + VI translations
  + tool metadata
  + theme registry
      ↓
schema validation
      ↓
source/provenance validation
      ↓
EN/VI parity validation
      ↓
precision/safety invariants
      ↓
compiled content artifacts
      ↓
static pages + runtime bundles
```

Recommended generated artifacts:

```text
generated/content-manifest.json
generated/source-manifest.json
generated/tool-manifest.json
generated/theme-manifest.json
generated/content-version.json
```

Generated files are build products, not canonical authoring sources.

## 6. Domain/resolver layer

Pure functions only where practical.

```ts
resolveAgeContext(profile, planDate)
resolveDevelopmentGuidance(context, content)
resolveFeedingGuidance(context, content)
resolveSleepGuidance(context, preferences, content)
resolveSafetyGuidance(actualContext, content)
composeNow(domainOutputs)
```

Rules:

- no date math in UI components;
- no prose in resolver logic;
- no theme behavior in domain logic;
- no tool-specific medical rules outside shared guidance contracts;
- deterministic input + content version = deterministic output.

## 7. Theme/UI layer

UI consumes semantic tokens from the active theme definition. Components must not import Baby Modern Glass-specific colors directly.

Theme details: `GUI_DESIGN.md`.

## 8. Tools layer

Tool discovery is registry-driven:

```text
ToolRegistry
  → route/navigation metadata
  → lazy-loaded tool module
  → optional guidance dependencies
  → safety/evidence labels
```

Tools may be fully client-side. Guidance-linked tools reference canonical claim IDs rather than duplicating medical prose.

Details: `TOOL_PLATFORM.md`.

## 9. Evidence Operations layer

Evidence watcher responsibilities:

- scheduled checking;
- conditional fetch/caching;
- canonicalization/fingerprinting;
- source-specific extraction;
- diff generation;
- dependency impact mapping;
- review-required state/PR generation;
- audit log.

It must not directly mutate release-approved health guidance in production as a side effect of a detected source change.

Details: `EVIDENCE_UPDATE_ENGINE.md`.

## 10. Storage model

### User-side v1

`localStorage` may store:

- optional child profile;
- UI language;
- theme family/mode;
- sleep planner preferences;
- tool-specific non-sensitive preferences;
- content version last seen.

Do not store data in cookies when local storage is sufficient. Avoid exact child data in URLs.

### Repository/build-side

Git is the primary source of truth for reviewed content/configuration.

Versioned state should include:

- source registry;
- canonical claims/actions;
- translations;
- tool definitions;
- theme definitions;
- source-monitor configurations;
- review metadata.

## 11. Content versions and release artifacts

Every production build gets:

```ts
interface ContentRelease {
  contentVersion: string;
  builtAt: string;
  gitSha: string;
  sourceRegistryVersion: string;
  localeVersions: Record<string, string>;
}
```

Meaningful guidance changes should be rollbackable independently from unrelated UI code where feasible.

## 12. CI pipeline

Minimum checks:

1. install / dependency integrity;
2. type-check;
3. lint;
4. unit tests;
5. content-schema validation;
6. source-ID/provenance validation;
7. EN/VI key + semantic-critical parity checks;
8. coverage matrix;
9. safety/precision invariants;
10. tool registry validation;
11. theme token completeness;
12. static route generation;
13. production build;
14. optional E2E/visual/print checks.

## 13. Deployment topology

### v1

```text
GitHub
  → CI/build
  → static export
  → static/shared hosting/CDN
```

### Evidence watcher

```text
GitHub Actions scheduled workflow
  OR small cron worker
    → outbound fetch only
    → diff/report/PR
```

The watcher does not need inbound public endpoints.

## 14. Future backend boundary

Only add a user-facing backend when a feature truly needs it, such as:

- encrypted sync;
- account recovery;
- cross-device history;
- notification delivery;
- multi-caregiver collaboration.

Do not introduce a backend solely because evidence monitoring needs scheduled compute.

## 15. Security boundaries

- Treat external source HTML/PDF as untrusted input.
- Never render fetched source HTML directly into the app without sanitization/approved syndication behavior.
- No arbitrary script execution from source content.
- Do not bypass authentication/paywalls/robots/terms.
- Validate generated content before commit/release.
- Lock dependency/tool versions where practical.
- Use least-privilege credentials for automation.

## 16. Architectural decision summary

| Decision | Choice |
|---|---|
| Public runtime | static-first |
| User profile | local-only in v1 |
| Canonical content | Git-tracked structured data |
| Public/personalized content | one compiled graph |
| Tools | registry-driven client modules |
| Themes | tokenized theme registry |
| Evidence watcher | separate scheduled operational plane |
| AI dependency | none required for core architecture |
