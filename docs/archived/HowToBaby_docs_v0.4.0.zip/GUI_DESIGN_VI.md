\
# GUI_DESIGN — Bản tiếng Việt

> Bản English là canonical. Theme ban đầu là **Baby Modern Glass**, nhưng kiến trúc phải cho phép đổi theme mà không rewrite component.

## UX direction

Calm, modern, warm, trustworthy; dễ scan trên mobile; professional hơn parenting blog nhưng không quá clinical.

## Navigation

**Now · Feeding · Play & Development · Sleep · Safety · Tools**.

Sources/Methodology/Editorial/Disclaimer/Changelog là trust destinations global.

## Theme engine

Tách:

```text
Theme family = baby-modern-glass
Mode = light | dark
```

Token layer:

```text
Foundation → Semantic → Component → Theme values
```

Component chỉ dùng semantic/component token, không raw hex.

CSS var gợi ý: `--htb-color-canvas`, `--htb-color-surface-glass`, `--htb-color-text-primary`, accent per domain, radius/shadow/glass blur.

## Baby Modern Glass

Light: sáng nhưng không nhạt/chìm; card đủ opacity/border, text strong.

Dark: deep cool/tinted canvas, vẫn baby-modern chứ không generic black SaaS.

Glass blur chỉ enhancement; nếu unsupported/reduced transparency thì dùng surface opaque hơn nhưng hierarchy giữ nguyên.

## Future themes

Có thể thêm `minimal-clean`, `high-contrast`, `paper-soft` chủ yếu bằng token/config chứ không fork component.

## Now

Child/context summary → What matters now → Feed/Play/Sleep/Safety focus cards → example timeline → relevant tools → sources/freshness.

## Tools hub

Group theo purpose: Soothe & Sound, Plan & Routine, Calculate, Track, Print & Share. Tool card phải cho biết utility hay guidance-linked nếu cần.

## Audio UX

Không autoplay; có Play/Pause/Stop/volume/timer/fade; có thể persistent mini-player sau khi user chủ động play. 432 Hz chỉ là preset/audio preference, không therapeutic claim.

## Evidence/Safety UI

Hiển thị rõ Official/Evidence synthesis/Typical/Example/Practical/Product heuristic. Safety severity dùng icon/text/structure chứ không chỉ màu; urgent/emergency không giấu trong drawer.

## Print

Letter/A4; print profile riêng, không cố in nguyên glass UI; bỏ controls, giữ hierarchy, tránh gradient bị cắt, source phù hợp bản in.

## Accessibility

Keyboard, focus, contrast, reduced motion/transparency, no color-only semantics, audio controls có accessible labels.
