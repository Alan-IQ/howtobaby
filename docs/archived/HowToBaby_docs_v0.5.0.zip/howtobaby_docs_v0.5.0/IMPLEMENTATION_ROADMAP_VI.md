# IMPLEMENTATION_ROADMAP — Bản tiếng Việt

> Bản English là canonical cho phase/gate.

## Phase 0 — Docs/repo baseline

Chốt bộ docs v0.5.0, repo structure, CI skeleton, deployment decision.

## Phase 1 — App shell + Theme Engine

Next.js/TS static export, Theme Registry, Baby Modern Glass Light/Dark, AppShell/Header/Nav, responsive/print scaffold. Gate: component không hard-code theme palette.

## Phase 2 — Content/source schema

SourceRecord, Claim/GuidanceBlock/applicability/precision/review schemas, EN/VI framework, coverage/provenance validation, trust page scaffold.

## Phase 3 — Age/context + Browse

Date utilities, corrected-age proxy, actual/browsed/preview isolation, browse-by-age, optional local profile, public static routes.

## Phase 4 — Play & Development

Migrate prototype, stage map, activities, corrected age, stage navigator, source audit, print.

## Phase 5 — Sleep + Safe Sleep

Official duration matrix, safe sleep, newborn responsive mode, nap/wake heuristic, settling vs behavioral methods.

## Phase 6 — Feeding + Feeding Safety

Feeding resolver, readiness, texture, responsive feeding, allergen, choking metadata, formula/breast-milk handling.

## Phase 7 — Personalized Now

What matters now + Feed/Play/Sleep/Safety cards + Know/Do/Why/Watch/Source + timeline + adjustment + freshness.

## Phase 8 — Tools + Audio MVP

Tool Registry/Hub/Shell, shared AudioSession, Lullaby Player, Ambient/Frequency Player có optional 432 Hz, timer/fade, mini-player nếu UX tốt. Gate: không therapeutic 432 Hz claim.

## Phase 9 — Evidence Watch v1

Source monitor registry, adapters CDC/FDA/AAP/WHO phù hợp, hash/section diff, source→claim impact, reports, scheduled GitHub Actions. Semantic change không auto-deploy.

## Phase 10 — Trust/SEO/print/accessibility

Methodology/Sources/Editorial/Disclaimer/Changelog, static metadata/sitemap, print QA, accessibility/performance.

## Phase 11 — Public v1 hardening

Full source audit, content version freeze, EN/VI parity, tests/build, rollback, production deploy, privacy/security review.

## Phase 12 — Post-v1

PWA/offline, more Tools, logs/reminders, multi-child/sync, recalls, AI-assisted Evidence Watch, Ask HowToBaby, additional domains/locales.

## Cross-phase rules

- Không build final Now trước domain resolver ổn định.
- Tool không duplicate medical prose.
- Không làm AI rewrite trước deterministic monitoring/provenance.
- Không thêm user backend chỉ vì watcher cần scheduled compute.


## Bổ sung roadmap v0.5.0

- **Phase 0:** dựng repo/package ownership theo `REPOSITORY_STRUCTURE.md`; `evidence/cache` gitignored.
- **Phase 2:** thêm `ClaimSourceRef`, `SourceLocator`, source status/access mode, các evidence reverse indexes; làm `SourceChip`, `EvidenceDrawer`, `ReferenceList` sample ngay từ đầu. `official-guidance` không có direct/primary source phải fail CI.
- **Phase 4–6:** domain claim khi ship phải mở được provenance/original source, không đợi tới cuối project mới gắn citation.
- **Phase 7:** Now reuse cùng claim IDs + provenance với public pages.
- **Phase 8:** guidance-linked Tool reuse claim provenance, không source URL riêng.
- **Phase 9:** watcher detect locator move, dùng canonical reverse index, cache full source temporary/gitignored và giữ history khi source đổi.
- **Phase 10:** hoàn thiện `/sources`, `/evidence/...`, revision history và trust UX.
- **Phase 11:** mọi release-approved health/safety claim phải pass provenance + original-source-link/status validation.

Cross-phase: không maintain References riêng ở page, không copy medical prose/source URL vào Tool, không commit routine full third-party source snapshots.
