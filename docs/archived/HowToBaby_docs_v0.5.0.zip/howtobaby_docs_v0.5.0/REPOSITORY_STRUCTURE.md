# REPOSITORY_STRUCTURE — HowToBaby

> Canonical repository-layout and code-ownership contract. This document defines where authored knowledge, runtime code, themes, tools, evidence-monitoring code, generated artifacts, and temporary source material belong.

## 1. Goals

The repository structure must make these boundaries obvious:

- the web UI **renders** knowledge; it does not own medical prose;
- canonical guidance is authored as structured data;
- source provenance is stored beside the knowledge model, not scattered through pages;
- evidence monitoring is operational infrastructure, not part of the user-profile runtime;
- Tools can reuse canonical guidance without duplicating it;
- themes can change without rewriting product components;
- generated output can always be rebuilt from authored sources;
- copyrighted/restricted source material is not casually committed to the public repository.

A single repository is preferred for v1. Separate repositories or services should be introduced only when operational scale or access-control requirements justify them.

## 2. Recommended top-level layout

```text
howtobaby/
├─ apps/
│  └─ web/                         # Next.js public application
│     ├─ src/
│     │  ├─ app/                   # Routes/layouts only
│     │  ├─ components/            # App-specific composition components
│     │  ├─ features/
│     │  │  ├─ now/
│     │  │  ├─ feeding/
│     │  │  ├─ development/
│     │  │  ├─ sleep/
│     │  │  ├─ safety/
│     │  │  └─ tools/
│     │  ├─ storage/
│     │  └─ print/
│     └─ public/
│        ├─ icons/
│        └─ audio/
│
├─ packages/
│  ├─ core/                        # Pure age/context/applicability logic
│  │  ├─ src/age/
│  │  ├─ src/context/
│  │  ├─ src/applicability/
│  │  └─ src/types/
│  │
│  ├─ knowledge/                   # Canonical HowToBaby knowledge graph
│  │  ├─ src/
│  │  │  ├─ sources/
│  │  │  │  └─ registry.yaml
│  │  │  ├─ claims/
│  │  │  │  ├─ feeding/
│  │  │  │  ├─ development/
│  │  │  │  ├─ sleep/
│  │  │  │  └─ safety/
│  │  │  ├─ guidance/
│  │  │  ├─ translations/
│  │  │  │  └─ vi/
│  │  │  ├─ coverage/
│  │  │  └─ schemas/
│  │  └─ generated/                # Rebuildable; never canonical authoring
│  │
│  ├─ ui/                          # Reusable presentation primitives/components
│  │  ├─ src/primitives/
│  │  ├─ src/components/
│  │  ├─ src/evidence/
│  │  └─ src/accessibility/
│  │
│  ├─ themes/
│  │  ├─ src/core/
│  │  └─ src/baby-modern-glass/
│  │     ├─ shared.ts
│  │     ├─ light.ts
│  │     └─ dark.ts
│  │
│  ├─ tool-platform/
│  │  ├─ src/registry/
│  │  ├─ src/runtime/
│  │  ├─ src/audio/
│  │  └─ src/safety/
│  │
│  ├─ i18n/
│  └─ validation/
│
├─ tools/                           # Tool feature modules
│  ├─ lullaby-player/
│  ├─ ambient-audio/
│  └─ ...
│
├─ evidence/                        # Internal evidence-operations code/state
│  ├─ adapters/
│  │  ├─ cdc/
│  │  ├─ aap/
│  │  ├─ fda/
│  │  ├─ who/
│  │  └─ generic-web/
│  ├─ watcher/
│  ├─ diff/
│  ├─ dependency-graph/
│  ├─ reports/
│  ├─ state/                        # Fingerprints/metadata only where appropriate
│  ├─ cache/                        # Temporary fetched material; gitignored
│  └─ schemas/
│
├─ scripts/
│  ├─ validate-content.ts
│  ├─ validate-sources.ts
│  ├─ validate-provenance.ts
│  ├─ validate-translations.ts
│  ├─ build-knowledge-index.ts
│  ├─ build-evidence-index.ts
│  ├─ generate-public-pages.ts
│  └─ evidence-watch.ts
│
├─ docs/
│  ├─ PROJECT_PROFILE_v0.5.0.md
│  ├─ DOCS_INDEX.md
│  ├─ REPOSITORY_STRUCTURE.md
│  ├─ GUIDANCE_CONTENT_CONTRACT.md
│  ├─ EVIDENCE_PROVENANCE.md
│  ├─ SYSTEM_ARCHITECTURE.md
│  ├─ GUI_DESIGN.md
│  ├─ TOOL_PLATFORM.md
│  ├─ EVIDENCE_UPDATE_ENGINE.md
│  └─ IMPLEMENTATION_ROADMAP.md
│
├─ tests/
│  ├─ content/
│  ├─ integration/
│  ├─ e2e/
│  └─ visual/
│
├─ .github/
│  └─ workflows/
│     ├─ ci.yml
│     ├─ deploy.yml
│     └─ evidence-watch.yml
│
├─ package.json
├─ pnpm-workspace.yaml
├─ tsconfig.json
└─ README.md
```

## 3. Canonical ownership

### `apps/web`

Owns routing, composition, browser interaction, local storage integration, and product-shell behavior.

Must not own:

- canonical health/safety prose;
- source URLs embedded ad hoc in page components;
- age/stage business rules;
- raw theme palettes.

### `packages/core`

Owns deterministic logic such as:

- date/age calculation;
- corrected-development context;
- actual/browsed/preview context;
- applicability predicates;
- pure resolver primitives.

Must not contain user-facing medical prose.

### `packages/knowledge`

Owns the reviewed content graph:

```text
SourceRecord
  → ClaimSourceRef
  → Claim
  → Applicability
  → GuidanceBlock / Action
  → Translation
```

It is the only canonical location for evidence-backed HowToBaby knowledge.

### `packages/ui`

Owns reusable visual components and evidence/safety presentation primitives. It receives structured data; it does not decide what is medically applicable.

### `packages/themes`

Owns design tokens and theme-family implementations. Product components consume semantic tokens only.

### `packages/tool-platform` and `tools/*`

Own utility runtime contracts and individual tools. Guidance-linked tools depend on canonical claim IDs rather than duplicating medical guidance.

### `evidence/*`

Owns scheduled source monitoring, normalization, fingerprinting, diffing, and impact analysis. It may create reports/PRs but must not silently become the canonical medical author.

## 4. Dependency direction

Allowed conceptual direction:

```text
apps/web
  → core
  → knowledge
  → ui
  → tool-platform

tools/*
  → tool-platform
  → core
  → knowledge public APIs
  → ui

evidence/*
  → knowledge schemas/registry
  → evidence state
  → reports
```

Disallowed examples:

- `knowledge` importing from `apps/web`;
- `core` importing React/UI code;
- a Tool importing arbitrary page prose;
- evidence adapters modifying JSX;
- themes importing domain resolvers;
- page components defining source records inline.

Avoid circular package dependencies. CI should enforce dependency boundaries when practical.

## 5. Authored vs generated vs temporary data

### Authored and Git-tracked

- source registry metadata;
- canonical English claims;
- claim-to-source references and locators;
- applicability rules;
- Vietnamese translations;
- Tool definitions;
- theme definitions;
- monitor configuration;
- review metadata;
- changelog/corrections.

### Generated and rebuildable

Examples:

```text
packages/knowledge/generated/content-manifest.json
packages/knowledge/generated/source-manifest.json
packages/knowledge/generated/evidence-manifest.json
packages/knowledge/generated/route-evidence-index.json
packages/knowledge/generated/content-version.json
```

Generated files are never the editing source of truth.

### Temporary / normally gitignored

- fetched HTML/PDF used only for comparison;
- parser scratch files;
- screenshots of external sources;
- large source snapshots unless reuse rights and retention policy explicitly allow them;
- browser/cache state.

Default location:

```text
evidence/cache/
```

## 6. Knowledge file organization

Prefer small domain-oriented files over one giant YAML file.

Example:

```text
packages/knowledge/src/claims/feeding/
  milk.yaml
  solids-readiness.yaml
  allergens.yaml
  choking.yaml
  formula-safety.yaml
```

Stable IDs must survive file moves.

Example:

```text
feeding.solids.start
sleep.safe.back_to_sleep
development.6m.social.laughs
```

Do not derive canonical IDs from filenames or display titles.

## 7. Source registry organization

Start with one registry if manageable:

```text
packages/knowledge/src/sources/registry.yaml
```

Split only when needed, for example:

```text
sources/
  cdc.yaml
  aap.yaml
  fda.yaml
  who.yaml
  other.yaml
```

A build step must merge and validate all source IDs globally.

## 8. Evidence-monitor state

The monitor may persist:

- ETag;
- Last-Modified;
- source metadata hash;
- monitored-section hashes;
- check timestamps;
- parser version;
- prior normalized fingerprints;
- change classification.

Do not assume the public Git repository is an appropriate archive for full third-party source documents.

For restricted/copyrighted sources, prefer:

```text
metadata + URL + locator + hash + temporary cache
```

over full retained copies.

## 9. Public evidence output

The build may generate indexes used by the web app:

```text
claimId → sourceRefs
sourceId → claimIds
route → claimIds → sourceIds
sourceId → public source metadata
```

The public app must receive only the metadata needed for transparency and navigation; internal monitor state or copyrighted cached source content must not leak into the client bundle.

## 10. Git and review model

A health-content pull request should make the provenance change reviewable in one diff whenever possible:

```text
claim text
+ claim source refs/locators
+ source metadata if changed
+ EN/VI update
+ review status/date
+ changelog entry when parent-facing meaning changes
```

Git history is part of the audit trail but does not replace the explicit provenance model.

## 11. Workflow ownership

### `ci.yml`

Runs product/content validation and build checks.

### `deploy.yml`

Deploys an approved static build only after required gates pass.

### `evidence-watch.yml`

Runs source monitoring and creates reports/issues/PRs. It must not bypass release review.

## 12. Initial implementation simplification

The physical package split may be introduced incrementally, but the logical boundaries are required from Phase 0.

If early development benefits from fewer packages, use aliases/directories that mirror the final ownership. Do not build a monolithic `src/data.ts` or embed knowledge directly in components with the intention of “cleaning it up later.”

## 13. Repository definition of done

The repository baseline is acceptable when:

- every canonical artifact has one obvious owner;
- medical prose is absent from UI/business-logic files except display-only labels;
- source records and claim source references are schema-validated;
- temporary external-source material is gitignored by default;
- generated manifests can be deleted and rebuilt;
- package/import boundaries have no known circular dependency;
- public build does not expose child-profile data or internal evidence cache;
- docs in `DOCS_INDEX.md` agree on ownership.
