# SYSTEM_ARCHITECTURE — HowToBaby

> Canonical software architecture for the public web app, content build system, tools platform, and evidence operations.

## 1. Architectural goals

- Keep the public product static-first and privacy-preserving.
- Make guidance, tools, themes, translations, and source provenance schema-driven.
- Allow source monitoring to run independently of user traffic.
- Make every published content version reproducible and rollbackable.
- Avoid a future rewrite when Tools, Evidence Update Engine, or optional sync are added.

## 2. Three-plane architecture

```text
┌───────────────────────────────────────────────────────────────┐
│  PUBLIC RUNTIME                                               │
│  Next.js static export + client personalization + tools       │
└───────────────────────────────────────────────────────────────┘
                         ▲ compiled artifacts
                         │
┌───────────────────────────────────────────────────────────────┐
│  BUILD / CONTENT PLANE                                        │
│  schemas → source registry → content graph → i18n → pages     │
└───────────────────────────────────────────────────────────────┘
                         ▲ reviewed changes
                         │
┌───────────────────────────────────────────────────────────────┐
│  EVIDENCE OPERATIONS                                          │
│  scheduled adapters → fingerprints/diffs → impact → PR/review │
└───────────────────────────────────────────────────────────────┘
```

The Evidence Operations plane may run in GitHub Actions or a small scheduled worker. It is not a request-time backend for child profiles.

## 3. Repository/package boundaries

The detailed folder tree, package ownership, dependency direction, authored/generated/cache boundaries, and workflow ownership live in `REPOSITORY_STRUCTURE.md`.

Architecture-level requirements:

- `apps/web` renders product surfaces and owns no canonical medical prose;
- `packages/core` owns deterministic age/context/applicability logic;
- `packages/knowledge` owns the canonical SourceRecord → ClaimSourceRef → Claim → Guidance graph;
- `packages/ui` owns reusable presentation/evidence primitives;
- `packages/themes` owns semantic theme definitions;
- `packages/tool-platform` and `tools/*` own utility modules;
- `evidence/*` owns monitoring/diff/impact operations and temporary source cache;
- no public runtime bundle may include internal evidence cache or unnecessary third-party source snapshots.

A single repository is preferred for v1. Physical package boundaries may be introduced incrementally, but logical ownership is required from Phase 0.

## 4. Public web runtime

### 4.1 Static-first

- Generate public age/topic/trust pages at build time.
- Client JavaScript is used for local profile personalization, theme/language preferences, interactive Tools, and preview state.
- No child profile is sent to a server in v1.

### 4.2 Route families

Conceptual routes:

```text
/
/now
/feeding/...
/play/...
/sleep/...
/safety/...
/tools
/tools/lullaby
/tools/audio
/sources
/evidence/...
/methodology
/editorial-policy
/medical-disclaimer
/changelog
```

Exact slugs can change without changing architecture.

### 4.3 Public and personalized content

Both resolve from the same compiled content graph. Do not fork medical prose into SEO-only copies.

## 5. Content build pipeline

```text
source registry
  + claim source references/locators
  + canonical English claims
  + applicability rules
  + VI translations
  + tool metadata
  + theme registry
      ↓
schema validation
      ↓
source/provenance validation
      ↓
claim↔source↔route/tool reverse-index generation
      ↓
EN/VI parity validation
      ↓
precision/safety invariants
      ↓
compiled content artifacts
      ↓
static pages + runtime bundles
```

Recommended generated artifacts:

```text
packages/knowledge/generated/content-manifest.json
packages/knowledge/generated/source-manifest.json
packages/knowledge/generated/evidence-manifest.json
packages/knowledge/generated/claim-evidence-index.json
packages/knowledge/generated/source-claim-index.json
packages/knowledge/generated/route-evidence-index.json
packages/knowledge/generated/tool-evidence-index.json
packages/knowledge/generated/tool-manifest.json
packages/knowledge/generated/theme-manifest.json
packages/knowledge/generated/content-version.json
```

Generated files are build products, not canonical authoring sources.

### Public provenance compilation

The build must derive citation surfaces from canonical provenance rather than maintain separate page reference lists:

```text
ClaimSourceRef/SourceLocator
  → claim-evidence index
  → route/tool evidence index
  → SourceChip / EvidenceDrawer / References / Print
```

Evidence detail pages and `/sources` consume the same generated indexes. They are read models, not a second authoring store.

Detailed contract: `EVIDENCE_PROVENANCE.md`.

## 6. Domain/resolver layer

Pure functions only where practical.

```ts
resolveAgeContext(profile, planDate)
resolveDevelopmentGuidance(context, content)
resolveFeedingGuidance(context, content)
resolveSleepGuidance(context, preferences, content)
resolveSafetyGuidance(actualContext, content)
composeNow(domainOutputs)
```

Rules:

- no date math in UI components;
- no prose in resolver logic;
- no theme behavior in domain logic;
- no tool-specific medical rules outside shared guidance contracts;
- deterministic input + content version = deterministic output.

## 7. Theme/UI layer

UI consumes semantic tokens from the active theme definition. Components must not import Baby Modern Glass-specific colors directly.

Theme details: `GUI_DESIGN.md`.

## 8. Tools layer

Tool discovery is registry-driven:

```text
ToolRegistry
  → route/navigation metadata
  → lazy-loaded tool module
  → optional guidance dependencies
  → safety/evidence labels
```

Tools may be fully client-side. Guidance-linked tools reference canonical claim IDs rather than duplicating medical prose.

Details: `TOOL_PLATFORM.md`.

## 9. Evidence Operations layer

Evidence watcher responsibilities:

- scheduled checking;
- conditional fetch/caching;
- canonicalization/fingerprinting;
- source-specific extraction;
- diff generation;
- dependency impact mapping;
- review-required state/PR generation;
- audit log.

It must not directly mutate release-approved health guidance in production as a side effect of a detected source change.

Details: `EVIDENCE_UPDATE_ENGINE.md`.

## 10. Storage model

### User-side v1

`localStorage` may store:

- optional child profile;
- UI language;
- theme family/mode;
- sleep planner preferences;
- tool-specific non-sensitive preferences;
- content version last seen.

Do not store data in cookies when local storage is sufficient. Avoid exact child data in URLs.

### Repository/build-side

Git is the primary source of truth for reviewed content/configuration.

Versioned state should include:

- source registry;
- claim-source relationships and locators;
- canonical claims/actions;
- translations;
- tool definitions;
- theme definitions;
- source-monitor configurations;
- review metadata.

## 11. Content versions and release artifacts

Every production build gets:

```ts
interface ContentRelease {
  contentVersion: string;
  builtAt: string;
  gitSha: string;
  sourceRegistryVersion: string;
  localeVersions: Record<string, string>;
}
```

Meaningful guidance changes should be rollbackable independently from unrelated UI code where feasible.

## 12. CI pipeline

Minimum checks:

1. install / dependency integrity;
2. type-check;
3. lint;
4. unit tests;
5. content-schema validation;
6. source-ID + claim-source relationship/locator validation;
7. official-guidance direct-source requirement;
8. claim/source/route/tool reverse-index validation;
9. original-source link/public-source metadata validation;
10. EN/VI key + semantic-critical parity checks;
11. coverage matrix;
12. safety/precision invariants;
13. guidance-linked Tool provenance validation;
14. theme token completeness;
15. static route/evidence-page generation;
16. production build;
17. optional E2E/visual/print checks.

## 13. Deployment topology

### v1

```text
GitHub
  → CI/build
  → static export
  → static/shared hosting/CDN
```

### Evidence watcher

```text
GitHub Actions scheduled workflow
  OR small cron worker
    → outbound fetch only
    → diff/report/PR
```

The watcher does not need inbound public endpoints.

## 14. Future backend boundary

Only add a user-facing backend when a feature truly needs it, such as:

- encrypted sync;
- account recovery;
- cross-device history;
- notification delivery;
- multi-caregiver collaboration.

Do not introduce a backend solely because evidence monitoring needs scheduled compute.

## 15. Security boundaries

- Treat external source HTML/PDF as untrusted input.
- Keep fetched monitoring documents in temporary/restricted cache by default; do not expose them in public bundles or commit them merely for convenience.
- Never render fetched source HTML directly into the app without sanitization/approved syndication behavior.
- No arbitrary script execution from source content.
- Do not bypass authentication/paywalls/robots/terms.
- Validate generated content before commit/release.
- Lock dependency/tool versions where practical.
- Use least-privilege credentials for automation.
- External evidence links must use canonical authority URLs and safe link handling; evidence links must not use affiliate/tracking redirects.

## 16. Architectural decision summary

| Decision | Choice |
|---|---|
| Public runtime | static-first |
| User profile | local-only in v1 |
| Canonical content | Git-tracked structured data |
| Public/personalized content | one compiled graph |
| Tools | registry-driven client modules |
| Themes | tokenized theme registry |
| Evidence watcher | separate scheduled operational plane |
| Public provenance | generated from canonical claim-source graph |
| Full third-party source storage | temporary/minimized by default; not canonical repo content |
| AI dependency | none required for core architecture |
