# SYSTEM_ARCHITECTURE — Bản tiếng Việt

> Bản English là canonical.

## Kiến trúc 3 plane

```text
PUBLIC RUNTIME
  static Next.js + client personalization + Tools
        ▲
BUILD / CONTENT PLANE
  schema → content graph → i18n → generated pages
        ▲
EVIDENCE OPERATIONS
  scheduled source monitor → diff → impact → PR/review
```

Evidence watcher có thể chạy GitHub Actions/cron worker; không phải user-profile backend.

## Repo gợi ý

```text
apps/web
packages/domain
packages/content-schema
packages/content
packages/i18n
packages/ui
packages/tools-core
packages/tools-audio
packages/validation
services/evidence-watch
scripts/*
docs/*
```

## Runtime

- static public routes;
- child profile local-only;
- client JS cho personalization/theme/language/tools;
- public và personalized dùng cùng compiled content graph.

## Content build

```text
source registry + claims + applicability + VI + tools + themes
→ schema validation
→ provenance
→ EN/VI parity
→ precision/safety invariant
→ compiled manifests
→ static pages/build
```

## Resolver

Date/age math không ở component; prose không ở business logic; theme không ở domain logic; tool không được hard-code medical rule riêng.

## Tools

Tool Registry quyết định navigation/route/module/guidance dependencies. Guidance-linked tool reference canonical claim IDs.

## Evidence operations

Scheduled fetch, cache, canonicalize, fingerprint, diff, source→claim impact, report/PR. Không tự mutate release-approved medical content vì một source vừa đổi.

## CI

Typecheck/lint/unit + content schema + provenance + EN/VI parity + coverage + safety/precision + tool registry + theme completeness + static generation + build + E2E/visual/print khi cần.

## Backend tương lai

Chỉ thêm user-facing backend khi thực sự cần sync/account/notifications/collaboration. Không thêm chỉ vì evidence watcher cần schedule compute.


## Repo/provenance v0.5.0

- Chi tiết folder/package nằm trong `REPOSITORY_STRUCTURE.md`; `SYSTEM_ARCHITECTURE` chỉ giữ boundary cấp kiến trúc.
- `packages/knowledge` sở hữu `SourceRecord → ClaimSourceRef/Locator → Claim → Guidance`.
- Build sinh `claim-evidence-index`, `source-claim-index`, `route-evidence-index`, `tool-evidence-index`; SourceChip/EvidenceDrawer/References/Print đều dùng các index này.
- `/sources` và `/evidence/...` là read model sinh từ graph, không phải content store thứ hai.
- CI phải validate direct source cho `official-guidance`, source link, reverse indexes và provenance của guidance-linked Tool.
- Evidence cache/full fetched HTML/PDF không được lọt vào public bundle và mặc định không commit vào Git.
